--
-- PostgreSQL database dump
--

\restrict L3np4IpXaWkkLm7x4rLt9wMuKz4TfFUJBX0T6ANJKIYTbjpq5wesMWcKFA6Od9G

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: AccountStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AccountStatus" AS ENUM (
    'ACTIVE',
    'EXPIRED',
    'DISABLED'
);


ALTER TYPE public."AccountStatus" OWNER TO postgres;

--
-- Name: PlatformEnum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PlatformEnum" AS ENUM (
    'DOUYIN',
    'KUAISHOU',
    'XIAOHONGSHU',
    'BILIBILI',
    'WEIBO',
    'WECHAT_VIDEO',
    'TIKTOK'
);


ALTER TYPE public."PlatformEnum" OWNER TO postgres;

--
-- Name: PostStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PostStatus" AS ENUM (
    'DRAFT',
    'PUBLISHING',
    'PUBLISHED',
    'FAILED',
    'SCHEDULED',
    'CANCELLED'
);


ALTER TYPE public."PostStatus" OWNER TO postgres;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'MEMBER',
    'VIEWER',
    'OWNER',
    'MANAGER'
);


ALTER TYPE public."UserRole" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    platform public."PlatformEnum" NOT NULL,
    "platformUserId" text NOT NULL,
    nickname text NOT NULL,
    avatar text,
    bio text,
    followers integer DEFAULT 0 NOT NULL,
    following integer DEFAULT 0 NOT NULL,
    status public."AccountStatus" DEFAULT 'ACTIVE'::public."AccountStatus" NOT NULL,
    cookies text,
    "proxyConfig" text,
    metadata text,
    "lastActiveAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL,
    "teamId" text,
    "groupId" text
);


ALTER TABLE public."Account" OWNER TO postgres;

--
-- Name: AccountGroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AccountGroup" (
    id text NOT NULL,
    name text NOT NULL,
    color text DEFAULT '#409EFF'::text NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public."AccountGroup" OWNER TO postgres;

--
-- Name: Asset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Asset" (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    url text NOT NULL,
    size integer DEFAULT 0 NOT NULL,
    width integer,
    height integer,
    duration integer,
    "mimeType" text,
    tags text,
    "folderId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public."Asset" OWNER TO postgres;

--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    action text NOT NULL,
    resource text NOT NULL,
    detail text,
    ip text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- Name: Competitor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Competitor" (
    id text NOT NULL,
    platform public."PlatformEnum" NOT NULL,
    "platformUserId" text NOT NULL,
    nickname text NOT NULL,
    avatar text,
    bio text,
    followers integer DEFAULT 0 NOT NULL,
    following integer DEFAULT 0 NOT NULL,
    status public."AccountStatus" DEFAULT 'ACTIVE'::public."AccountStatus" NOT NULL,
    note text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public."Competitor" OWNER TO postgres;

--
-- Name: CompetitorSnapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CompetitorSnapshot" (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    followers integer DEFAULT 0 NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    likes integer DEFAULT 0 NOT NULL,
    comments integer DEFAULT 0 NOT NULL,
    posts integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "competitorId" text NOT NULL
);


ALTER TABLE public."CompetitorSnapshot" OWNER TO postgres;

--
-- Name: DailyStats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DailyStats" (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    platform public."PlatformEnum" NOT NULL,
    followers integer DEFAULT 0 NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    likes integer DEFAULT 0 NOT NULL,
    comments integer DEFAULT 0 NOT NULL,
    shares integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "accountId" text NOT NULL
);


ALTER TABLE public."DailyStats" OWNER TO postgres;

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    content text,
    read boolean DEFAULT false NOT NULL,
    metadata text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    plan text DEFAULT 'FREE'::text NOT NULL,
    status public."AccountStatus" DEFAULT 'ACTIVE'::public."AccountStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Organization" OWNER TO postgres;

--
-- Name: Post; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Post" (
    id text NOT NULL,
    title text,
    content text,
    "mediaUrls" text,
    tags text,
    "publishAt" timestamp(3) without time zone,
    status public."PostStatus" DEFAULT 'DRAFT'::public."PostStatus" NOT NULL,
    "platformUrl" text,
    "errorMsg" text,
    metadata text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "accountId" text NOT NULL
);


ALTER TABLE public."Post" OWNER TO postgres;

--
-- Name: PostStats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PostStats" (
    id text NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    likes integer DEFAULT 0 NOT NULL,
    comments integer DEFAULT 0 NOT NULL,
    shares integer DEFAULT 0 NOT NULL,
    saves integer DEFAULT 0 NOT NULL,
    "collectedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "postId" text NOT NULL
);


ALTER TABLE public."PostStats" OWNER TO postgres;

--
-- Name: Team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Team" (
    id text NOT NULL,
    name text NOT NULL,
    "organizationId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Team" OWNER TO postgres;

--
-- Name: TeamMember; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TeamMember" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "teamId" text NOT NULL,
    role public."UserRole" DEFAULT 'MEMBER'::public."UserRole" NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."TeamMember" OWNER TO postgres;

--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    phone text,
    password text NOT NULL,
    name text NOT NULL,
    avatar text,
    role public."UserRole" DEFAULT 'MEMBER'::public."UserRole" NOT NULL,
    status public."AccountStatus" DEFAULT 'ACTIVE'::public."AccountStatus" NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "organizationId" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Account" (id, platform, "platformUserId", nickname, avatar, bio, followers, following, status, cookies, "proxyConfig", metadata, "lastActiveAt", "createdAt", "updatedAt", "userId", "teamId", "groupId") FROM stdin;
cmp5a5kgl0003g1ll3mqft7lc	DOUYIN	scan_1778750551	抖音	\N	\N	0	0	ACTIVE	7fa08582575c6c0edab4944b982d12e0:54e11058ff83182a442ab041412236d4:44ae2acd4b06d54566d467fa292e788c4c4198b22e7b8b8382eb49f6c20fdf999c084448a5d8a51e0b85831286fff11ff61c39ab4f5a1efa2b3dcbd9cfd1f78043045e495561f97531392eb81b591156108bac2a7942ce8fc776118d79725e16c6c1fdda50b92d2120a5ddcbd5cb035f89e98192800baf73bac74dd1db71d3e2c31c107636b7653ec725e00d28e309cc5d6e6c8aa449badd734ece61587ae5778e7eeb34b5859c1f1086650e7d13dca56b1f256116184d73889bbf722dfecbf05aee005ee401fb42f3724be7fdfe9201b48a9fd4522e2e3711cab5d89188695429490dfd73915bff2442f774b2c897543e3178b65bd740abba1825d767142f29d1dd4dfb482c04496bb692fb563f54517a980f1df24ae82a408f4025d60d6334894a2105faf31e6955b3a2221b1d901077d2b7e710211f6ece15e62b24efb91feef3c5c21852be4a54818a17450048f117d0734b7ba5cd39ecb80861af48fb4bd664e75e19a971c3993eb2d32fa4b80bc30eb1defbfe2d5b8dc1857044558dc54770a7820a2117f28cbfbe7ce6f5a15c770e181bb153e8fcf7d33da5d3fd433cba5e0cb728bff421f5ebbd2f3e13ab43da7cc03016c2d8bf125dabf301966b31954891bb7628870ab01e0639f3fbc16454acf30d56e5fa2fc38ab76e438aa14cba447943c1818094e16af4b03ce280a344ff1607edcf4adab6fad1b8d925ef82d44b41202f3a1c494b7c6bc367ffaaa62bb74da65ca256563477b04cab1d8b9bfb78a3e6804d0f5ebd96743891661d47c242ed931e97319a792f46f83701513800f6f74ff6fdfab2e3cea1db08429e0a3cafb4758975785e3925da331c84ffb132bd925ecbff413a45e61afa8f8996222538978d50b9e1420502125a25ac644e33cedd1c30ef4673fbf041e84bd697740c6dde2ffa7e40858a3b108ecfc8a546a69898862cf532297a36b25fac9cd53544699da00525391dfa21efb44aeb5a6c72711014c260720719c3ba14e3db366335059147796a1617d62dc4618312ef9fcd899dd8f2053518aa964dbcec3da61ac896b4b40a0b61c4d19dcb272986a3f799f67ac7fdb9338168a9431736f9ffeba449df02fa9b0a5660fed2c9d425bcf23682f5adefd942810ee8adf3ec65fbabe3faa426024a2a61832ec2e91fa7c0998c6fb5f4aff70a2e096ac5a3f63264cbdd0605048834c04c7a964f1a49e5700ccce4db391d7dc9ee76e04db478c811cbc99be71e36a9fc4a20bb2e3d30673f45e0e119cffc99ab2ade60fe00e87d13070c50bdb01e45f5b55867372512e6db93ecd0f7822ac7cbee7a30abf8b647fdeaba112b24b5000b033a7b9ed9c7a76175a5a9b144a3ac0609f0dcc28732fdf661847100cc44c61e29a9714301bf57c78da24f09070992678f13a205506f14aa6802ccf9888f026c628cb28f4de21648826a2d94fa92a650d6394b7cf6f5350f7aba97b6761b9a76d988b258ea26260eb4ca7f7383d6f3debc56d8a358f07a67baf922f27c51eb199b66271d25b8550d418731f1af824040d419108f0360c7f0eec21218228739ed254d6518d97724674f5c21643f533bb14ce75f3f67db8b2c691f0f2ca6add1590ce0452abf7c9aec978de71c80710c14dade591ec977a7c5753b67e178144c1dec6bac996055791292faf21f54a7faf3c323db7d511c4b17a8fb3111dd12328a38ae84b9996d07212e08a02a2e062d316aee4dc3e8b8b6bb1727b2bded19c0077a2e9da339871030cb4873f957a4151bba8a07360c49f0f8d7b737ac00b9e9cc76ec67cd2ee5a6d494147d60bce749cf38dcb99d169c753cca9141423395c8fa4a0f7c53507fb8ad4711711a53a12d9ada8b3ac3077a475b70bf3c84f3e9a332ad911aa375898f18374e5027cddac71f28f665b68e2a26875158beecfc93da3510e352966da0bf6a7e727ba61d7f5cbb48ead6e771fefec3ab3e3591b61a1b622141b145148d3f7749d0ca4d2b2f0b6e5a1ba605c64ba24d7e46544e3abe7086b3ec04cf92f4274caf3d525d238c15ae2d115850c6407c529d28d008425dd9834406db75d09ef26d24aefac5800adfb46270465f33dc439d996c4a6463545d194227d90a987c71e213622d07fae8fa08741c92bf237f6637f8538c986742de2cf756cdc0bb43b320720566e76bf2c1af9a5fcef7e9c307946f81725f589923fb7dca354a4a4c4183d351d1472322d774ded4087957a90190d5eab7af23e5267d82aa9ec1d0fa458905b49ba3ce6c96d5083a3ebededaebf0f1ac06e202f0d166327fbf61162f60e60e83e51f79142740d39244eaa961ce80a9b1c6966162b69fde1cdda3c68dd3d4b9c73e1008647725ad4e34255af0b8b91353e6211cff48c01b83f127a884524c8ff9314a3db6d5c4e249ab8bb1299f7bec98e657f1c37240db63b62ae6793a18485a54631a12d18eda4d96ea550a5a5c2853cec3b8d00e83bc0ff39d1f4fd7a3d7f2fc1f3506a799d2732e564f5e05976d8af71c6ac8b7f8367d2351ce3016e905faa93dccff48b9d238378f1aab290936ebef67c93814e4d6e6000879c748b90b05efc447cb389c706a9b706f1c363dcffe07a85eb446b601e68053a6913da566d206a158fb0d1278742d33fc56f54a79ad0c53d5682670e00436ca9450d8fdee435856ff0eee3d10a04ed8e901251d0a49a13bb11d506436ac86a9ef2de3cafc16f85493e2f95b133e583ff26777c49b4ef38b177237f3f3881ae4b4d7c87e30e75b69805209633be59def0a05f6d6eaa983d1cd537fcbfc9e8fd000b451aa276174ff7d36361e3713adb500d587913cfac0c9a12398258ce854eb740177fc79afab8c5fe376ba13ecf7ee93e09a3de7798579a3ddd1ee1d32892febc2cba75d62a10a11794d00e976860e2a481b09590a7d30a352c19e2abb3b9fb6388c5bd55b8f658e15d2f7c25cd99c6121e294672368557bd16d8be73dfa1e17e61dfc40e3c06a0cf79a2e2368ab4eccb21a05b1dbc173c608914ac1daff80df10112437ee40bac3354c50f5f4931efac64f5205dbb7f3c9e60c2d6299c3e46bff4030db3b575355c4ede806707db21094666358641adcc2ebf7c9e9311c6ec4481c1cf11cf6a00d8e93ffbbe62a8d158743b3ff8b4a576fa2ff3eedfcd991112279c1aed00255e2387219fdfe9641514fe1a147317b02d5e5de204f3808b5c02b298dbb55dbac932ba499f588814930df0c43a65c7d6b308885bb71a04d9a9bc8d257a19cc88976e8e5b59c72ece19f6f29b307d19aacfdd23f9ea181608ab342156feb211710c66dd934b018cf0f9d275c8a10cbcd25c646fad19d90d3f440a5b5f63b0fb4	\N	\N	\N	2026-05-14 09:22:35.349	2026-05-14 09:22:35.349	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5a8h2x0005g1ll2u818b04	XIAOHONGSHU	scan_1778750686	小红书	\N	\N	0	0	ACTIVE	9d9a4f5e1a2040534d6fe602f798ab32:a7ecb11963d103d8aff82fdc366f8ae8:1886cbcb358e13c4986f059092695f619d93d98c6f5f62985312eb64a4fc98b31c43457c5eaa726abced40eb460bad10fe16da482f2e27ac157de3e697b65ff81d3b4b3820525153d96b88a071ec333e1ab41a08778c644205cf166e351788e46558504d9a456c1b5e7d4e8d449a78b1b3ba1ea29b8fd7d7d2e70ec2288fd5ee4880cd3f8beadbd7396733fccfd0ac76de690c5d10e76228c58dcc79fc10aa74f3cc84ed4678af440c4f16a2c72cb15fc0d1975e18d1bcb08e750489e2fd76441e3dc638f3b7c6f7b8e61cee8ff8d8d7555b960fbb687ee160513e14609233d5aca5012d41fdcd03ce54a205bc6a32f12f2acdb47f58fca6287fae51e9b979fb29ef1dfb0eb18915e7dfe6655592a2c5dcf39492c7d3fcf980819df27b0f752729e9d1018706098f59f3af1d229b293604ae81df7ded80b3d64f768126f8d4af2f0f3f67fe3f11106a48bdc8b5b63608147b512f78df4ec238f33de38b6b34744090224f6089d6345cb559916f73bc95a1583214dd5ca703bf8f3a4f784cf55253f9835cb17ad2c22605a2f1b2ff3c256692c40a019dd2aff53b6e3ae88d36f29223caf6be4de186dd7ea642f091ae1ac80d3097e83fd8ff491e55b534cda848256c2d7031ab81be1ff566f45562d29802fb2274f1546f8258a910c1e651258b12adf2b6660cfa2af0207fbadeb264ffa6cbae70d21a7e42f021c358eedc4b21dc3f371172d3768517e6bf210f3feef132e7c18270bdec024f30328a343bd41b86e16d9d9c77e7abf9215428f4cca40ac6cb4f8d10de77681bfa28	\N	\N	\N	2026-05-14 09:24:50.937	2026-05-14 09:24:50.937	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5a8r420007g1llqulu4jqb	XIAOHONGSHU	scan_1778750699	小红书	\N	\N	0	0	ACTIVE	f5ced34c213c7fa454da8ee433d002c0:24b86eed4c9d75f0858037f730bb24d9:bdb150a93e4d8df74fbfbe40c01152a1fba7417827f03af4bcccab84956b80315d19484191b4ec1779ff87da262ccf7de3458c0d1455205671b3ed274e6a3b4563a4b1cfb1cd40953b19d140a5d5348535910691ea01cf83b9c296a67fd8868362313ee53533999fc049d4871a562c84827132e3e93c8e7fc3ce6f5dcc3edb7eb63f30459e0fef33e4cf4f18a581f65aed417cc1321e313645c24001e8bda8b82692506fb6eaba96be76236b5a5640fde4832b87bcd27ef04bf7992a84f366d19173e08b45caef856f0aa0e71b22e5966ba4c518bfe43cfcefc93d9e1d2cb6cba737f9cd0d1c0b30a54d2225ef42a7b477522a6b55e539dc62aec4487c678172488defb724170d70a9f099b11c624771eeeeda7cb5cf7ef5aec9dfcdb698999b896571ce660c171fde5ee8aed02b631ea1d856858d762383f7fbdc871d29cf2c9e340621d43d3939398477bcc4ceca5d3cc990bc3b4e14bc1baa17d1d8b0f9457c5fd04400ae41632522726be88d802b06c798e09e884ac91d4560d42b8819e1fb7b7cfc624cc8fa3e840cc34aa8c131edda1204711e7099f9bb96afeb06f80a35657dd6523e802bf6d10f9f00c7d35e6b3cd311fb2b787d4ea855d8f6bfd5d57e30ec52bd9bcf5c048c22b41b4b5a50f8746455d42dcefb0fd5c0a5e2ccf504381ded69284e60bd55f6835c70f3737f2a8de12bf8753114f02af9d5b296fdea99850ade20d1b894e67633f33ff9015aa6a8df853335bd175cf6fc0aa6e3d37fee5b2342e688dbfa5983b6723cb443e49ee2bca43c3af7bbb8fb9d	\N	\N	\N	2026-05-14 09:25:03.938	2026-05-14 09:25:03.938	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5a90o20009g1ll5phdy09p	XIAOHONGSHU	scan_1778750712	小红书	\N	\N	0	0	ACTIVE	fedb5139d84ea8c2ac2a32ecdc02d32f:81287fa5d3aa769371db84e268b756a8:0cf756f65dd136713a1cac845eeaaac6337a4041aea018ddf274a63ea7db35fdf543b441bf157d0413e3bc3e2052293d61ea134df4dfe9c5dacbb390dd8fb4a1c9a5381e500d7edd40626fc7034ff44bae8523241836eee5efa818cb851467cf0e1669f512209e82585546241bde7ec6a61f0a2c68ecdaaa175572683b1a5615798998b906b6d4e59b2a4d820659783eec6809a60cae70c03c571bc4c8492b6adeb54cf2b94da9f98f77c4232393123737ae7d45d48f893d3fd71039fd5681127b9e4d08630c11088fe3639aa9e0f7415c82d678a454d1fc16569fb5800c351c7c2110cf9b26e801980a755e1e5debb77ad24eb93fc2cbdfde4e6fb1c0e8e5cf41ab86b74c1d93cb59feb123a9e32212b7893d96bb7ffd35128b96dc6fd4bf09e6b6b485b9ba90fff531fe3de8b339b0d68b121cabdebd1fd35a3852a7e8a821d21eaa6bbe051612a0cb0d597bb672c6f6c7ba08a1358d34e582369be9405ebe2da3ad904340ee2629deb72282a7729b39dfd306a3b664781601f16dd424bb75de3f59c80ed622d7e8d55bff859d11ea644bdbac2db6ae0a3b3ce8039e2667f2677b2b118a5087414e59463ff4e4e0a10b65f780cc4bf718a114a01cdfd6ee3f8e8b642c5c8b02c0a3bcad99f25613c401e85d028bd4242471a7ab4a5dd11d706bc8d44437f24f95c8c56391d148c3dfbb9f628b624c485f65895c85254ddde1a74954e077059d6c3ca906a54b0cb4d0ec56c9b6be50f9d4f02fe30a20ea78672278d99bd529c9e012fad21453803bb2459132ab9c6d7e20b8a62f	\N	\N	\N	2026-05-14 09:25:16.322	2026-05-14 09:25:16.322	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5a9a71000bg1lla9gurhe5	XIAOHONGSHU	scan_1778750724	小红书	\N	\N	0	0	ACTIVE	812bf9554baf3b0ece269adb3617c5e2:526221f44d54aecf0fef4f8bab781f77:f09612f381efd2bba5f2343c98bb8005ceb159c0192fc8b5acc1f3a0a29a91df4ee69dfd25dc0b5e525955885e470ce26ff7e366a67e77456c5cb93cc6eda978b815b3964f1029d5c7e4bdf55a55852c2665e2df793240a6d7f47188fbb3ad2ca63de4767b8dc671ad3fb268c44b7647f3aa8e409630d3fc6b6872af0c16ef305831d04a2bfc7dece2d059dc4840daa11674a5ed0f294957ddd14b13b232136694ab6325ce9ed8359e8ae28590f1248b466dcfad9534515035a5b0fadf841d4c2278bf9106bc7cce51ee715efe99a3906457ad94a575069cd2856f620a52c6b8a7fb67a25a96685d84120b73a94d073357f4e83e0f08153ebe552a1bc4cd0e8ff4bfe3833532428a90e99f2d9f3197ca366499ffe050cfe0603c5114ee5ad6a58e1c9b046aee84690be344c258a410ff18781effbd84a247abd1d82a7e6aacfbd37fc84eb1dd697d3908a00fea607259bac84872f4b75d53bbe577fac1d9752702e42ad30591dbb3eadae42186dc3a76f154e1c8d67b5b5f3736fa10e6fb74581a5ef2dc370f222ebdc9d104daa68bc100eb8a29d7b66581111243c495fbad4f6429c9bb7e2a5b8edc682dfae15cefaa2b8762e97726e8ab94b71d1c1d90c0db68b113ac47da9f8e8b73498883bf85b1bec2bcb856111eb46f02a9747ce3671f15bef2175ca6352512a4314653c86d6ed5acf3e61187354b1e7c2f3393e6e6638e4a2d54feb0b24417fdf8be13f0354a568644eaec004d1f206b9dab41e4869e0700b13df24f0efbb0dc05dfa2834d65dff8b34e51b27c1c6d199e	\N	\N	\N	2026-05-14 09:25:28.669	2026-05-14 09:25:28.669	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5a9d1p000dg1llseit3b50	WECHAT_VIDEO	scan_1778750728	视频号	\N	\N	0	0	ACTIVE	47e53a60b0df50b1a0c8963083d9c2bf:ea3712d839a737ad76a42a46a2cad04f:f66f496157613e5e0038cda4fb53f52483c2c2189e803a3ae0799353d32f5e81c8cc92b5ee1b99853beb1e04b56d938f5a26e063c74f265768ee5108551aec58fbe7c3d93c5e51452d035668a916ce5cbed0453421a1d3c37a17702321577d94a56a9bed75288b80f44076283ff68849a47f5859516596a26d55466602509bf193ce0f4a86fd0bbfee0fe30e	\N	\N	\N	2026-05-14 09:25:32.366	2026-05-14 09:25:32.366	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5a9jhs000fg1lljzoe38ye	XIAOHONGSHU	scan_1778750737	小红书	\N	\N	0	0	ACTIVE	02d9bac913f21205539e011c1881a103:9f8c0f96a895559154eb3c4dc499faa8:2aa6fc1fc6e6729e4549c0b464ced618fd4c4205f77b0e63f9b737816a079390dd47925b176c934b489c546846436af5ba49c536737dda57effb8b4e0de23fe8d89ec766ec7905b7a50a44879e8629dba72fcd3aff015c63c5bbc551d20d8d62e525bc46c357dbd3a85f12c570ecf399c1115f13e71df884d2a82fa4e01b7c3a28bab254abd3d05b84d246adad3c4b340fb7b465c097a946a2645fa886943240f60aa9933ce90d1d3deb7eefc895cf6f3a344fa99ab526af8bcb19a2102c84537914f3711c44993327af7828edf685a880e5e9da4d5f21a936f491b13b7c3ba65a4561726e174a52dcec6481c9a99f38ab3b3d5de6678f9bddae8460c20c4aa7fdbbb052e60db41cc6df6e4016c80317c72f017ec1c2848cb07b38a6932d940fad406195bf30614b58ddcd64e3410485b453b977d347ae564309133d5cbcef64daee0f256053e52fb6bf13729cec82085ae8fd2e51577dc7ad4b8701d253ba9c600ba912b4a6b09c3383318fe78a8baf42a3cfd36898aa1e539ef8187cab4ec9ae98d1f1e77c383d7fed7b0d076470a877aefc50d2e78470dab3dc677985f86c126dca9bf3369afdc72d3fbbc807e73bbb68b0850873178635f188293385be0f72864178fc96e9a3cb6b5066b576e0c18f3d4118eccc77a37ee1b503b48f250054735d84de989148ebd0cba502ec8f5478c815d8c979577ec22e2d05f273b879aab9fc789bde41a2ff97977835c579d953ec7d4017f0c2c670ab2ace0bc31ccb68adb0309f9a9be1fc0fc400bd19ac2de542fc0c2a735cf9eaea50	\N	\N	\N	2026-05-14 09:25:40.72	2026-05-14 09:25:40.72	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5a9t32000hg1lld9b8p6ni	XIAOHONGSHU	scan_1778750749	小红书	\N	\N	0	0	ACTIVE	6c9f75b9d629d7b3939d5e5aad731a82:08876910934adcbbf9dff01119686dea:fc955e784b0ede5c2d29619d605201996ad1513609c8ac8c122dc2c8e13550ca22f2223eee049f3d92057f84e7536e9a4b4f389d07313721afffa4b8ae1ada7f8415ed416643d0840a73191cd8ce16b2d2015ae7664fa92e87a2f8c7273906f04410167aaf343f72bc7c6595240af8445271afb4cd1d605c1b4082ed072f64a2d574304d66dee3a21329be3352b20d25c3142b7d3ab4a97852cea26f06fe87aa0c3153eaa781176c33d18c1e4aff698b1298e0efa87a597cb0f3884ed69f2a55c9cd7171a792f4fcc21438a52979eb29bd2a998627acde5027ceaeed8f933e6ded890c992819fded03480a8cb63e2a7f26fa73d02cb840b2ddc7a55f7586a0c89dab25a77d1cd7b8ab7a659db38dd19d206a6c7cf91873a8da8b4c93f9f75444a6d30b1b32ebcbff190af6f1086d1d211ef062bdcd5a36f3c110f9b02154149b3b035815a05fa566f7d834cf8ea61b37a4ffc5d34ae90dacd060a1c20c41208b3b33681382d1a61c67a690858c15d71eb7edf47e3c66aafc2c50b9a523861ceaa43a0d5d3dbcadb6afe33c0d6580102472e5e402d803a7d051f4093575d7465ce97553c797be6e83639cf38e904c4de7b9a1e87adfeaff943dbf22936f3f907f3f51ccbfa29e5da39c92c6e5ee55c69a261b3bd2287ca896767bf1a401c95e47887d90a5bc87ebfc477265ec2d8c53fb211e9b53434663a3b6bb5de758f0e1ba7f105ebe4de319497a3e1909260b152e8e7dd68f3ab8484ae050ad57944b1d350a2f9966511cbac4dceef090b61ac5f3b6143d2759fe23abaaa9fd	\N	\N	\N	2026-05-14 09:25:53.15	2026-05-14 09:25:53.15	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5aa8f2000jg1lll1oshpul	XIAOHONGSHU	scan_1778750769	小红书	\N	\N	0	0	ACTIVE	252fc04e9144a8c66d194f41eae338d2:74188569db31fe12191324becdfbd184:e02f21e709363c2406421f7f0984f0b68e255556d510828ff250b722f6a9e280562b6b20c1913755c68274438c6f68386adf6e1304de4d3ab1efb351e08cb904d1fea600978b09489a233bfa2bdcb48f3ad32d6a90a491d16c8e3f8b546d1d58f9a61d9d3e894ba65d7cf0a05a286ddb9e432995e8f4c7712563c24863749b1cb1dc28e9601957b9993e6dda6e6d223a75efb6c1fb6c92600000c6e878e9cb2136331f35e8b876370f5841139b03f00a1f252a2275649eaee51b18db36acd039f4e7a859615c9e5892caec9335be03fbafe048381189f1c3bdbf49da644a1237f4c64eca86eb45ae49fe1f9d26007b308af9f555b9192f2fdf05b627764aee6affdbdc25b63c73aada20c4ea882bd19429d2b879ad9dc1ba69c0190d40fbf0ccea422114ff3f06c186f58c8dcae78f8be1a9850b3f7b8872a3ee768d31d43a885dc1c4bd29b4032c1f876e827e9c819a178ec1082bd5595831e68d3258f5a2d4d4bd421822bc2042242301ad866d25ad315c8d5baaff909ef87e3d6200307171fc1626fec22ffd14fb2d505b1570f498925ae5200dad8bdd2b7ee544e86705f4fd6d613212a0e4a002dd89529ff619481dc1dad71da8487e92aa69b0fdf8f03099e02df3da1576789fefc1f24c3bf2a2de27635fa500271485fae925cafa4bca0939a2ad4106dfd8cdba2fd1eb598369b9a1328df095211555907114d1accaf33f20011c57b548e812a325185a637bbefc382b96c0617bec2f98c7016b41751620962257564907ab4de36cb307c6e3489311cbf29fb9c26d1d4f8c	\N	\N	\N	2026-05-14 09:26:13.022	2026-05-14 09:26:13.022	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5aakd4000lg1lllkpbjklc	WECHAT_VIDEO	scan_1778750784	视频号	\N	\N	0	0	ACTIVE	c4a9c9b1d7ae28112b0e1eeebfaf2c8d:07ee55da84e3bcb79ed9f388fd81ee2c:05688bb8f5c77cf1766c0d6aabda9efaf3a78b35d0e7d146f7e0ac5f695499045c95b7f7b8dc1f74379cb1412222531e92ed323560d145c4d5e781ad735f2017df5f5e6d143b24005786a19576c6a6a1e80b18f98dbc91616368877bd93a186d4f20e575b5faa00c6ef594520ebbaa100c132ea5dbef4945412ffa407aa55f5b794340b2d8cb8f8b06	\N	\N	\N	2026-05-14 09:26:28.505	2026-05-14 09:26:28.505	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5aav2f000ng1ll9gvk44za	XIAOHONGSHU	scan_1778750798	小红书	\N	\N	0	0	ACTIVE	3ca0a57a861c266ddb495184f412a832:bc4bcf358fe2cb9a18bda1139ad61c83:8fbca4d9c7a2d92b7b0443f50e7a37c68764b70b158827eed928191d90e2b8d4f190b9c38d085b2528956fe517fa76b5f80cc4c56d17c8ce71d09dc4307b427c876123cb3cf972b5f2913dd94c1b56b939586f5e2306ba65ff5599d73bc76e8b46b2ec958abc26b6a7bbfe51edada2b5e70c6f4cc3624ef3d9e8a4f12f1a7d29ed2d014c7d30ff88ad0b718a58a3c677ec85678e12a74f58911468c7cfbba68a55f27d5b84814b4d574f38d3accb7c2cee321476d1c78c5a8896e648c47fa25634f74afd8bba57b11ad6e190b5917198f71a6a92db8c51607f383947daaf4382b197c68a1faebd6ecce54e7b9176c71d98b0f19827b715318895230f2ef37208dc72a5ae29613a9e56814d2c189659e921223a4ddf27962bb4b52d28d5d7ab7bc3ef7b973e18af299dbe0e581ed33310a5de569ecdb60ad7f1417c175d51c517a564ba1b2cf090fdff1d73e6df7ef8360effcd55d983decbf787444b8e3f80417c29f30bfd43c236ffaf9a87f0d896841abf66207dae33b0be07aa1d8d8cf0d3618f63a6be2911abaeba7a238b1954873250d3b507e9760cb9b92948bb6d9856f01a387165f77c8aaae727abd2d9e4c590cfd252fb3f16e5659294f39a9804f4de24a5d7e055f1292f1ab9821a0772012fdbbf155d3f7d6165bdae96131d9371f8418dc489c2897e67b051cdc6087cc61a8756bae83cf0d0489370c2f301a231dd40aa304d7448adc685c85fb00fc251827e0ee5933a857c9ec4f6ac9e9c26117fcf0993528a69d5742b1a77534e73eccabc97b83e142d3cb16546	\N	\N	\N	2026-05-14 09:26:42.376	2026-05-14 09:26:42.376	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5ab9rg000pg1ll8lllus3n	WECHAT_VIDEO	scan_1778750817	视频号	\N	\N	0	0	ACTIVE	c81151f32d92132536cb35dcacf1bf9d:363468741b2d1d739d57571b17ce6297:b62767ea7d21056961d2479b69baeec1a8164db0f12de014f35bac4d0ade3150b107914b01a9b2ccaf70e6e1b2af1e4b74a80ac9e91f203b4d0006cdad4eb5e0ad4ffab0a6ef706647a241a9202c066f11bb3bc771f6f33297f947d2ff22af2b8a350bc510cd40da78e9b98a9ce5bfdd15cf00d570a92aac3c68e8b12a8f1349769399864396b28bbb38e8f9fe43	\N	\N	\N	2026-05-14 09:27:01.421	2026-05-14 09:27:01.421	cmp545tsj0000xcs52de3xwp3	\N	\N
cmp5abjt2000rg1llhbjjuaf9	DOUYIN	scan_1778750830	抖音	\N	\N	0	0	ACTIVE	dea740f9aba5afce8d38a4ab21a22647:e33982ec8b8aea8f70966f3f04423727:43c5004d8cfe23089a345d4be8e1cd79f4ea42f2e4090fba2d54d3e4b3ec14495d5ddb275193e6e28189846ea487c32e38fc2af9d832a1d090c8c90e6e32e5be2f303922c317cdb0923c6794f50a69d9622a61fb604a2621e1ae39977bd1ae77ee30662f27647341188163b6f396fcac5bf76298c386694648cf6db0f53571f85b3e6ebd7c64ab42dd556045a78c4bcb9eeb27d2da98c21b3ac72b734c61e2efad45b1b3e6cba3d48369272ce1f5318fa4fa52abe0715724bea47ba6faafb18cbe5445a06851e5011c2d5994bc0fafe82487514665d8247036a9d684815df02ab0d74192a7ad75c5453db3faafb5d27af849572f852cb5ec55ccd7a29363b17cbff4ede9a64ca7ece879481a822010bd2dc481283754bc748f87c76dc461b7fe1daded355dd3b063ffae8514a2705088ccf99e3c45ce899005f9860cf61c4156605ba64b673f2ce83249b159f222cb3bd9e176c0aacd4d2655abe1d3bfe2ec1bc7b965aa59660f4a3e39733d8e3c3adf08523abe82a8392a6c66b320964abde375013a9a17ddc364b6c5efefb2ba2fd9b37aab30d66eef618d138ad8b952e92d7260b6e090315bd2e8d3bb6f36f4fe52aa497240523ecead5411ddec3368e51f229570edf93ca9b81e13f6d07d506859efceaaddac8dd5604e53635a7025ccde798a9ab0499bec17ba8c7fba83752ca3e28f1a936371ce3319cb07251794bf08474c786c9b96490997bd16ae930d32cb06f02803968611629b20d9cf19de4734888a014478ef6bacfdc53ea3be1637ffd7cd8e853c855e2636fd67b94bcce4b6633ffc8d65e30c0d44490614e2d8b0594f43f4e491b9e68e051aec0e4da9324dceb422a4cd59723a5abd371ce2eb49430a07e24b40dfa6d8bd56e8d1ae48970ae18117dfc034ea3e32c02ea11ab3db2d107dfd6e7b07639e8272139ac5d8376ea8d237b70a0371f0ce3abd3ee41961dc5e8cc0749ba73d39659462bf0808f8af68231eebaec6b8f1e1809bfd5fbe6b7ff3195775542ed32d9cfe33ac910c6b69f3a83be2b9e47ba7a266a6814c8adeb60e10c6c4d488866f91b4a9b2ecf0f31b931fe1b4bf8a894a522c8ce7629342a5b232e141bd093fa3645e053e2c45d9c6494faadc002ced5c09c2e80bd7e0f25a88dd317e2ba05fffb65426fd89bf2eef3c12d191f89b1a5ffcc436404d705e653a261e60b0a83cd9450a8e94b4d978669bb9d8a968cbd4571e4bd5494b85e71432b7621235055d22bc6d1bb7daf393ea75108315d59289391376b50c29acd981e0842881ea5dabf207cbd48e6e4fc54de8bc43785c46bd933481498142796b13016fab33f5f2f258ec5122fa765d5fd824f44ba50f2a9c3ffb3bf654a63964953745d3b269671be392fe73a05fc7de0eeb9d5a54291b2200777080346b9714ca253ec23e2500b5ef8d5d4eadd3ac7e8cf9c3801c1ab34ae20544e05c9d1c48a7130cb379c058b9d3edd84e99fb090eb436b96fcf090e83b047faa27240bd58c48ba2cc12100593f36207be4dc2d0398780ee68afc7b6936064b7496efae3a2d3cc091dbb440c9eda58316cb2435d845ab54af824fdc5842c0d6206e1826fa41e4f2ad7c94511a1e0f1af053024607e39eda07961aec50d29fe1c2ba9100fa6367d2402bb0d05230619f787bca40d6bdb21c6e8fbd69d31a77dc6693157a627c4792c6bf72155e9a54fb36036d0f0c7b5e4e3b5df84179c1e1488bb4ccc0f18a32132d47ab02e9bd2e65a0b78c4a617e2326cd9a0d3a9e0c0c5c1de3c9fccbba5ff18f69fb2bef4044f31778ca72ff7fe6edb92c207b4875f1e9d389cc176873e95766a736c82d66ac50d68a0812192c736a1285c27f444f6483f8ea3850faa5d5c39b6431ad61b5ced010599432e476c22310d7569b9a9778c0e48134f3f88c1dc755006abdf0139f85b88303383df957d133cb9fff49cbbfaaa8e7fa99dbba6f26ae461a477022437beae8ac91d666f53ea84a16d2d06090357a3884c529e6dce2e83849366da3ea5f71ec2f482dddb818330606dbe10344c1b3aa101cb7a77d435ff7dfe896042052cc6eb11b6dbf2e4277de516059730e7fe1753d88491650505fde4b122f9df9bf538012759a1b6db32bde9d06bd0e40e139f11641b6c34e882d92bcea95472c59a0d1734a71adf563eee6ab9f08523c60837d8f2ff67fb547957732a5727052d03e61337629411a074f27f794b0b83245621934aa444ad62e468fc1770bf0e6c0fe68293c4c20a6583a2d0108b5ab431fe344cc3fb0e1049844267521fe01375dbd1e287743c96af877619cf00ea1fd5c982b64dd8d5bb0a9b98f2d73af8a5ff5e35e10f064a05015e6f7e58c1e33c2c9f36a86613c8383b50416a2f2d532dabb7646f5a4e597cdb35849cb6595971c5c10836b92e1d60324a50d563a3fa1357a4106c16d2ac01c68d3d39301d2ca5075b22b146cf6546e48d30bb61c27d965471bbe35bfe7560fefc713c74d44c121480c03d6cfcae414f4a1c55aa918956b8ef60c992a3a0e88277ae3b1f3b4265b1daa52ba3a5392f2901d5ad8e313824e392c65fb287b9aa7c8e2c376a8672e880da9c474384e79f467a292ac5fe01c16470ca163411c5756889363e92f7970035f8b4d8c054be6fe0710d30d4f985a5e72d2a7b5187761bcf6b51b9b7e5bc6aa1667ef26e1fcd48bb17942155208f04f05369e5de1c74905a152f1f769324fbbfd95bb59c5d15703bdab4749786d26fbcbe039b6149ee9d5e9237779b94c6bde32773a50e7c870132c474b856ab8c2115bf944326a4fa6bd0649d860e4de80b8a1e1e5d232885ec2c5662e09e6304203af8b755361511bf72084bc786958c2134eaa5f80d9ccbda0f656a2192a5733defa64e1b3c8b2a99a8e32a33d264f7473f37126eeb46196b848c9ab1f0fba8f2244e1b7df4e663ac5d4338168abc3282b7019de35a3d8568c0d5c78181218268a044d7686df2c5f665578125bd1997723ac7f4d6f6ba596b6c433581d636e97f648d0481e35e9b3d49c2eadb0ec38c1e0738c381986d184a26391b23a8a484b3bcde8a3df9cc5362276181b040ead3daa7486f5637f5f4826a40f8c4aba10f014667fc872ae358a2af0898d1914a4b0e47e5ef903d719003e04619a2bbe4f0729f7ff97b4117c1ebfc7d573344b2cee455a734361b98559b9628492f04d72d79ee51e0b6e8af9b9b09896f88ac631594f2da0779a31a78f447ab24115d11f457529356890ce6dc46458721904194b2470e9fce08006cb7b0fae90030b0d0dd025898d6b65a162ca933a76aaaa2fa7530feeb4bc81ac6871cf1e7bbc80e027119638f37e31bb44278a35204	\N	\N	\N	2026-05-14 09:27:14.438	2026-05-14 09:27:14.438	cmp545tsj0000xcs52de3xwp3	\N	\N
\.


--
-- Data for Name: AccountGroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AccountGroup" (id, name, color, "sortOrder", "createdAt", "updatedAt", "userId") FROM stdin;
\.


--
-- Data for Name: Asset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Asset" (id, name, type, url, size, width, height, duration, "mimeType", tags, "folderId", "createdAt", "updatedAt", "userId") FROM stdin;
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, action, resource, detail, ip, "userAgent", "createdAt", "userId") FROM stdin;
\.


--
-- Data for Name: Competitor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Competitor" (id, platform, "platformUserId", nickname, avatar, bio, followers, following, status, note, "createdAt", "updatedAt", "userId") FROM stdin;
\.


--
-- Data for Name: CompetitorSnapshot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CompetitorSnapshot" (id, date, followers, views, likes, comments, posts, "createdAt", "competitorId") FROM stdin;
\.


--
-- Data for Name: DailyStats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DailyStats" (id, date, platform, followers, views, likes, comments, shares, "createdAt", "accountId") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, type, title, content, read, metadata, "createdAt", "userId") FROM stdin;
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Organization" (id, name, plan, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Post; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Post" (id, title, content, "mediaUrls", tags, "publishAt", status, "platformUrl", "errorMsg", metadata, "createdAt", "updatedAt", "accountId") FROM stdin;
\.


--
-- Data for Name: PostStats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PostStats" (id, views, likes, comments, shares, saves, "collectedAt", "postId") FROM stdin;
\.


--
-- Data for Name: Team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Team" (id, name, "organizationId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TeamMember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TeamMember" (id, "userId", "teamId", role, "joinedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, email, phone, password, name, avatar, role, status, "lastLoginAt", "createdAt", "updatedAt", "organizationId") FROM stdin;
cmp545tsj0000xcs52de3xwp3	test@test.com	\N	$2a$12$5qgr.eu0QL77DNGh3a1F7e2COUtX/9gr/0Q5.C9UcemQG4rBNJEvO	TestUser	\N	MEMBER	ACTIVE	2026-05-14 10:32:42.31	2026-05-14 06:34:49.747	2026-05-14 10:32:42.311	\N
cmp58hcdl0000g1llh7ajw8bu	testreg@test.com	\N	$2a$12$awu32.KtNmuOPz8AMwfEBejP77bSvpN9fA8KQKo7.BZSexftFUe/.	TestReg	\N	MEMBER	ACTIVE	\N	2026-05-14 08:35:45.514	2026-05-14 08:35:45.514	\N
cmp58kqra0001g1ll60szto2p	2889514244@qq.com	\N	$2a$12$Kv0IUQG1atjQi8vRbWyQfOSvFh7EZk45UaI2YUonRfe3NXTV899Lu	ddddkiii	\N	MEMBER	ACTIVE	2026-05-14 11:00:54.316	2026-05-14 08:38:24.119	2026-05-14 11:00:54.318	\N
cmp5qh82t0000ecpoc9mycixw	audit999@test.com	\N	$2a$12$HLOupiJvcrH.DQ9rjSxqTOda/9jwhI4nImKjIRzQNS/MsevAwvi0G	Auditor	\N	MEMBER	ACTIVE	\N	2026-05-14 16:59:33.029	2026-05-14 16:59:33.029	\N
cmp6i4kvb0000maabx4abhhpg	final-test@matrixflow.test	\N	$2a$12$HL07wiu8TKFD1/.rD7vNj.wNDTBvMEO/72c.y2aFRh5Ds.xEZQSLq	FinalTest	\N	MEMBER	ACTIVE	2026-05-15 05:53:32.714	2026-05-15 05:53:32.328	2026-05-15 05:53:32.715	\N
cmp6hmwez00002e0edf9locgw	test-verify@matrixflow.test	\N	$2a$12$e.0lVaAvUApfAK7yCA8xIOTQ0PkvseQjJCX9TBiYbgPuFSN2oCpTu	TestUser	\N	MEMBER	ACTIVE	2026-05-15 06:40:35.122	2026-05-15 05:39:47.483	2026-05-15 06:40:35.123	\N
\.


--
-- Name: AccountGroup AccountGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AccountGroup"
    ADD CONSTRAINT "AccountGroup_pkey" PRIMARY KEY (id);


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Asset Asset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Asset"
    ADD CONSTRAINT "Asset_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: CompetitorSnapshot CompetitorSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CompetitorSnapshot"
    ADD CONSTRAINT "CompetitorSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: Competitor Competitor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Competitor"
    ADD CONSTRAINT "Competitor_pkey" PRIMARY KEY (id);


--
-- Name: DailyStats DailyStats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DailyStats"
    ADD CONSTRAINT "DailyStats_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: PostStats PostStats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PostStats"
    ADD CONSTRAINT "PostStats_pkey" PRIMARY KEY (id);


--
-- Name: Post Post_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_pkey" PRIMARY KEY (id);


--
-- Name: TeamMember TeamMember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TeamMember"
    ADD CONSTRAINT "TeamMember_pkey" PRIMARY KEY (id);


--
-- Name: Team Team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: AccountGroup_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AccountGroup_userId_idx" ON public."AccountGroup" USING btree ("userId");


--
-- Name: Account_groupId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Account_groupId_idx" ON public."Account" USING btree ("groupId");


--
-- Name: Account_platform_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Account_platform_idx" ON public."Account" USING btree (platform);


--
-- Name: Account_platform_platformUserId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Account_platform_platformUserId_key" ON public."Account" USING btree (platform, "platformUserId");


--
-- Name: Account_teamId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Account_teamId_idx" ON public."Account" USING btree ("teamId");


--
-- Name: Account_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Account_userId_idx" ON public."Account" USING btree ("userId");


--
-- Name: Asset_folderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Asset_folderId_idx" ON public."Asset" USING btree ("folderId");


--
-- Name: Asset_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Asset_type_idx" ON public."Asset" USING btree (type);


--
-- Name: Asset_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Asset_userId_idx" ON public."Asset" USING btree ("userId");


--
-- Name: AuditLog_action_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_action_idx" ON public."AuditLog" USING btree (action);


--
-- Name: AuditLog_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_createdAt_idx" ON public."AuditLog" USING btree ("createdAt");


--
-- Name: AuditLog_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_userId_idx" ON public."AuditLog" USING btree ("userId");


--
-- Name: CompetitorSnapshot_competitorId_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "CompetitorSnapshot_competitorId_date_key" ON public."CompetitorSnapshot" USING btree ("competitorId", date);


--
-- Name: CompetitorSnapshot_competitorId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CompetitorSnapshot_competitorId_idx" ON public."CompetitorSnapshot" USING btree ("competitorId");


--
-- Name: CompetitorSnapshot_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "CompetitorSnapshot_date_idx" ON public."CompetitorSnapshot" USING btree (date);


--
-- Name: Competitor_platform_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Competitor_platform_idx" ON public."Competitor" USING btree (platform);


--
-- Name: Competitor_platform_platformUserId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Competitor_platform_platformUserId_userId_key" ON public."Competitor" USING btree (platform, "platformUserId", "userId");


--
-- Name: Competitor_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Competitor_userId_idx" ON public."Competitor" USING btree ("userId");


--
-- Name: DailyStats_accountId_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "DailyStats_accountId_date_key" ON public."DailyStats" USING btree ("accountId", date);


--
-- Name: DailyStats_accountId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DailyStats_accountId_idx" ON public."DailyStats" USING btree ("accountId");


--
-- Name: DailyStats_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DailyStats_date_idx" ON public."DailyStats" USING btree (date);


--
-- Name: Notification_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_createdAt_idx" ON public."Notification" USING btree ("createdAt");


--
-- Name: Notification_read_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_read_idx" ON public."Notification" USING btree (read);


--
-- Name: Notification_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Notification_userId_idx" ON public."Notification" USING btree ("userId");


--
-- Name: Organization_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Organization_status_idx" ON public."Organization" USING btree (status);


--
-- Name: PostStats_postId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PostStats_postId_idx" ON public."PostStats" USING btree ("postId");


--
-- Name: PostStats_postId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PostStats_postId_key" ON public."PostStats" USING btree ("postId");


--
-- Name: Post_accountId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Post_accountId_idx" ON public."Post" USING btree ("accountId");


--
-- Name: Post_publishAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Post_publishAt_idx" ON public."Post" USING btree ("publishAt");


--
-- Name: Post_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Post_status_idx" ON public."Post" USING btree (status);


--
-- Name: TeamMember_teamId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TeamMember_teamId_idx" ON public."TeamMember" USING btree ("teamId");


--
-- Name: TeamMember_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TeamMember_userId_idx" ON public."TeamMember" USING btree ("userId");


--
-- Name: TeamMember_userId_teamId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TeamMember_userId_teamId_key" ON public."TeamMember" USING btree ("userId", "teamId");


--
-- Name: Team_organizationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Team_organizationId_idx" ON public."Team" USING btree ("organizationId");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_organizationId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "User_organizationId_idx" ON public."User" USING btree ("organizationId");


--
-- Name: User_phone_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_phone_key" ON public."User" USING btree (phone);


--
-- Name: Account Account_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."AccountGroup"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Account Account_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CompetitorSnapshot CompetitorSnapshot_competitorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CompetitorSnapshot"
    ADD CONSTRAINT "CompetitorSnapshot_competitorId_fkey" FOREIGN KEY ("competitorId") REFERENCES public."Competitor"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DailyStats DailyStats_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DailyStats"
    ADD CONSTRAINT "DailyStats_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PostStats PostStats_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PostStats"
    ADD CONSTRAINT "PostStats_postId_fkey" FOREIGN KEY ("postId") REFERENCES public."Post"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Post Post_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Post"
    ADD CONSTRAINT "Post_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public."Account"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: TeamMember TeamMember_teamId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TeamMember"
    ADD CONSTRAINT "TeamMember_teamId_fkey" FOREIGN KEY ("teamId") REFERENCES public."Team"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TeamMember TeamMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TeamMember"
    ADD CONSTRAINT "TeamMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Team Team_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Team"
    ADD CONSTRAINT "Team_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: User User_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict L3np4IpXaWkkLm7x4rLt9wMuKz4TfFUJBX0T6ANJKIYTbjpq5wesMWcKFA6Od9G

